package unb.application.tps;

import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.ArrayList;
import java.util.UUID;
import java.util.logging.Handler;
import java.util.logging.LogRecord;

import android.widget.Toast;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.Adapter.*;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.content.Intent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;


public class PlanoPrincipal extends AppCompatActivity {

    BluetoothAdapter bluetoothAdapter;
    public static int REQUEST_BLUETOOTH = 1;
    Button conectar, ativarLed;
    Set<BluetoothDevice> dispositivosPareados;
    ArrayList<String> dispPareados = new ArrayList<String>();
    String[] listaDePareados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plano_principal);
        setupUI();
    }

    private void setupUI () {
        conectar = (Button) findViewById(R.id.btnConectar);
        //ativarLed = (Button) findViewById(R.id.btnLED);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        conectar.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bluetoothAdapter == null) {
                   Toast.makeText(getApplicationContext(), "Dispositivo não suporta conexão Bluetooth", Toast.LENGTH_LONG).show();
                    /*finish();*/
                } else if (!bluetoothAdapter.isEnabled()) {
                    Intent ativarBT = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(ativarBT, REQUEST_BLUETOOTH);
                } else if (bluetoothAdapter.isEnabled()) {
                    Toast.makeText(getApplicationContext(),"Conexão Bluetooth já está ativada",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void onActivityResult (int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
       if (requestCode == REQUEST_BLUETOOTH) {
           if (resultCode == RESULT_OK) {
               Toast.makeText(getApplicationContext(),"Conexão Blueatooth iniciada com sucesso",Toast.LENGTH_LONG).show();
                /*dispositivosPareados = bluetoothAdapter.getBondedDevices();
                if(dispositivosPareados.size()>0){
                    int counter = 0;
                    listaDePareados = new String[dispositivosPareados.size()];
                    for(BluetoothDevice dispositivo:dispositivosPareados){
                        listaDePareados[counter] = dispositivo.getName().toString();
                        counter++;
                    }
                    */
                listaDePareados = new String[10];
                listaDePareados[0] = "Matheus Veleci dos Santos";
                listaDePareados[1] = "Rafael Dias da Costa";
                listaDePareados[2] = "Otávio Alves Dias";
                listaDePareados[3] = "Túlio Abner de Lima";
                listaDePareados[4] = "Victória Goularte Resende";
                listaDePareados[5] = "Fábio Marques";
                listaDePareados[6] = "Fernando Nunes";
                listaDePareados[7] = "Murilo Cerqueira";
                listaDePareados[8] = "Eduardo Schuabb";
                listaDePareados[9] = "Luisa Arcoverde";
                Bundle nextActivity = new Bundle();
                nextActivity.putStringArray("Pareados",listaDePareados);
                Intent intent = new Intent("pareados_filter");
                intent.putExtras(nextActivity);
                startActivity(intent);
           }
        }
    }
}
